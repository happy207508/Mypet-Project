from django.contrib import admin

# Register your models here.
from .models import Pet2

admin.site.register(Pet2)