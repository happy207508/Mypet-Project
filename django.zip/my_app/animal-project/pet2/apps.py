from django.apps import AppConfig


class Pet2Config(AppConfig):
    name = 'pet2'
